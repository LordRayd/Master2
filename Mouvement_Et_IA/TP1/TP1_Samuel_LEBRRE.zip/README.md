# TP 1 - LEVENSHTEIN
## Lancement
Dans un terminal tapez: make et tous les fichiers se lanceront sucessivement
## Partie 1 - LCS
Algorithme en O(n)